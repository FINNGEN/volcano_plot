# volcano_plot
Volcano plot (aka LAVAA/Fauman plot)
